#!/bin/bash

make
make test
